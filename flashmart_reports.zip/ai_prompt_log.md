# Nhật ký hỏi đáp AI (AI Prompt Log)

## Prompt 1: Tìm hiểu lý thuyết JOIN
- **User Prompt:** "Trong cơ sở dữ liệu MySQL, mặc định từ khóa JOIN (khi không ghi rõ LEFT hay RIGHT) sẽ hoạt động như thế nào? Nó sẽ bỏ qua hay giữ lại các bản ghi không có sự trùng khớp ở cả hai bảng?"
- **AI Response Summary:** Trả lời về bản chất của mặc định `JOIN` trong MySQL chính là `INNER JOIN`, cơ chế hoạt động theo lý thuyết tập hợp (giao của 2 tập hợp) và lý do tại sao nó loại bỏ các dòng không trùng khớp.

## Prompt 2: Tìm hiểu về hàm COUNT với LEFT JOIN
- **User Prompt:** "Khi tôi sử dụng LEFT JOIN và đếm số lượng đơn hàng bằng hàm COUNT, tôi nên dùng COUNT(*) hay COUNT(tên_cột_khóa_chính_bảng_order)? Sự khác biệt khi kết quả trả về NULL là gì?"
- **AI Response Summary:** Giải thích sự khác biệt: `COUNT(*)` đếm cả dòng chứa NULL (trả về 1 cho Charlie), trong khi `COUNT(o.order_id)` bỏ qua NULL (trả về 0 cho Charlie).

## Prompt 3: So sánh hiệu năng Anti-Join vs Subquery
- **User Prompt:** "Hãy phân tích hiệu năng (Performance) của việc dùng LEFT JOIN kết hợp IS NULL so với việc dùng subquery NOT IN khi muốn tìm kiếm các bản ghi không tồn tại trong bảng khác."
- **AI Response Summary:** Phân tích thuật toán tối ưu hóa của MySQL Optimizer: `LEFT JOIN ... WHERE IS NULL` thường tối ưu hơn `NOT IN` (đặc biệt khi cột có chứa giá trị NULL) nhờ tận dụng Index scan tốt hơn.

## Prompt 4: Mở rộng thuật toán xử lý JOIN của MySQL
- **User Prompt:** "Trình bày thuật toán Block Nested-Loop Join (BNL) và Index Nested-Loop Join (INL) mà MySQL Optimizer sử dụng để thực thi câu lệnh LEFT JOIN."
- **AI Response Summary:** Mở rộng kiến thức nâng cao về cơ chế quét bảng index/drive table và bộ đệm join buffer của MySQL.