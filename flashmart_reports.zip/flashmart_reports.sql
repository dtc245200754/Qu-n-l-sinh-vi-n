1. Nguyên nhân lỗi của Legacy Script:
Ở Báo cáo Marketing: Lập trình viên dùng JOIN (mặc định là INNER JOIN). INNER JOIN chỉ lấy tập hợp giao nhau giữa 2 bảng. Vì Charlie chưa có dòng nào trong bảng Orders, câu lệnh loại bỏ Charlie khỏi kết quả.

Ở Báo cáo Kho vận: Dùng INNER JOIN nối Products với Orders. Do Keyboard chưa được bán ra nên INNER JOIN loại luôn Keyboard. Sau đó đặt điều kiện WHERE o.order_id IS NULL trên kết quả của INNER JOIN (vốn dĩ không chứa dòng nào có NULL) nên kết quả trả về trống trơn.

2. Mã nguồn SQL hoàn chỉnh đã sửa lỗi:
SQL
-- HỆ THỐNG FLASHMART (FIXED SCRIPT)
CREATE DATABASE IF NOT EXISTS flashmart_db;
USE flashmart_db;

-- 1. Tạo bảng và chèn dữ liệu mẫu
DROP TABLE IF EXISTS Orders;
DROP TABLE IF EXISTS Products;
DROP TABLE IF EXISTS Customers;

CREATE TABLE Customers (customer_id INT PRIMARY KEY, name VARCHAR(50));
CREATE TABLE Products (product_id INT PRIMARY KEY, product_name VARCHAR(50));
CREATE TABLE Orders (order_id INT PRIMARY KEY, customer_id INT, product_id INT);

INSERT INTO Customers VALUES (1, 'Alice'), (2, 'Bob'), (3, 'Charlie'); 
INSERT INTO Products VALUES (101, 'Laptop'), (102, 'Mouse'), (103, 'Keyboard'); 
INSERT INTO Orders VALUES (1001, 1, 101), (1002, 1, 102), (1003, 2, 101);

-- ========================================================
-- BÁO CÁO 1: Cho Marketing (Lấy tất cả khách hàng và số đơn đã mua)
-- ========================================================
SELECT 
    c.customer_id, 
    c.name, 
    COUNT(o.order_id) AS total_orders
FROM Customers c
LEFT JOIN Orders o ON c.customer_id = o.customer_id
GROUP BY c.customer_id, c.name;

-- Kết quả trả về:
-- | customer_id | name    | total_orders |
-- | 1           | Alice   | 2            |
-- | 2           | Bob     | 1            |
-- | 3           | Charlie | 0            |

-- ========================================================
-- BÁO CÁO 2: Cho Kho vận (Sản phẩm ế chưa từng bán ra - Anti-Join)
-- ========================================================
SELECT 
    p.product_id, 
    p.product_name
FROM Products p
LEFT JOIN Orders o ON p.product_id = o.product_id
WHERE o.order_id IS NULL;

-- Kết quả trả về:
-- | product_id | product_name |
-- | 103        | Keyboard     |