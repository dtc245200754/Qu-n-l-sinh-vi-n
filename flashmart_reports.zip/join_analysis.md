Nội dung giải trình lý do sử dụng COUNT(o.order_id) thay vì COUNT(*):

Lý do dùng COUNT(o.order_id) thay vì COUNT(*):

Trong truy vấn LEFT JOIN, khi một khách hàng (như Charlie) chưa từng phát sinh đơn hàng, dòng dữ liệu trả về cho bảng phụ Orders sẽ có toàn bộ các giá trị là NULL (bao gồm o.order_id IS NULL).

Nếu dùng COUNT(*): Hàm sẽ đếm số lượng dòng dữ liệu trả về bất kể giá trị chứa NULL hay không. Do đó, dòng dữ liệu của Charlie vẫn bị đếm là 1 (sai thực tế).

Nếu dùng COUNT(o.order_id): Hàm COUNT(tên_cột) có đặc tính kỹ thuật là bỏ qua các giá trị NULL. Do o.order_id của Charlie mang giá trị NULL, hàm sẽ đếm chính xác số lượng đơn hàng là 0.

Vì vậy, sử dụng COUNT(o.order_id) giúp giữ nguyên vẹn thông tin khách hàng chưa mua hàng và phản ánh đúng số lượng giao dịch thực tế.